"use strict";
exports.NickelRing = [
    { index: 0, img: '/assets/NyckelRing/page1.png' },
    { index: 1, img: '/assets/NyckelRing/page2.png' },
    { index: 2, img: '/assets/NyckelRing/page3.png' },
    { index: 3, img: '/assets/NyckelRing/page4.png' },
];
//# sourceMappingURL=mock-NickelRing.js.map