"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var slide_service_1 = require('./slide.service');
var AppComponent = (function () {
    function AppComponent(slideService) {
        this.slideService = slideService;
        this.title = 'NickelRing';
        this.mic_is_on = false;
    }
    AppComponent.prototype.onSelect = function (slide) {
        this.selectedSlide = slide;
    };
    ;
    AppComponent.prototype.after = function () {
        console.log("after", this.selectedSlide);
        if (this.selectedSlide == undefined) {
            var next_index = 0;
        }
        else {
            var next_index = ((this.selectedSlide.index + 1) >= this.howto.length) ? 0 : (this.selectedSlide.index + 1);
        }
        this.selectedSlide = this.howto[next_index];
    };
    ;
    AppComponent.prototype.before = function () {
        if (this.selectedSlide == undefined) {
            var next_index = this.howto.length - 1;
        }
        else {
            var next_index = ((this.selectedSlide.index - 1) < 0) ? this.howto.length - 1 : (this.selectedSlide.index - 1);
        }
        this.selectedSlide = this.howto[next_index];
    };
    ;
    ;
    AppComponent.prototype.getSlides = function () {
        var _this = this;
        this.slideService.getSlides().then(function (slides) {
            _this.howto = slides;
            _this.selectedSlide = slides[0];
        });
    };
    ;
    AppComponent.prototype.ngOnInit = function () {
        this.getSlides();
    };
    ;
    AppComponent.prototype.toogleMic = function () {
        var _this = this;
        this.mic_is_on = !this.mic_is_on;
        if (annyang) {
            if (this.mic_is_on) {
                var commands = {
                    'back': function () {
                        _this.before();
                    },
                    'next': function () {
                        _this.after();
                    },
                    'help': function () { alert("say 'next' or 'back' to navigate"); }
                };
                annyang.addCommands(commands);
                annyang.start();
            }
            else {
                annyang.removeCommands();
                annyang.abort();
            }
        }
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            providers: [slide_service_1.SlideService],
            template: "\n    <h1>How to :{{title}}</h1>\n    <div class=\"container-fluid\">\n      <div class=\"diapo_container row\">\n        <a class=\"col-md-2 arrow hidden-sm hidden-xs\" (click)=\"before()\">\n          <img src=\"/assets/before.svg\"/>\n          <span [class.hidden]=\"mic_is_on === false\">\n            precedant\n          </span>\n        </a>\n        <div class=\"col-md-8\" > \n            <div class=\"img_container\" *ngIf=\"selectedSlide\">\n              <img [src]=\"selectedSlide.img\" />\n            </div>\n        </div>\n        <a class=\"col-md-2 arrow hidden-sm hidden-xs\" (click)=\"after()\">\n          <img src=\"/assets/after.svg\"/>\n          <span [class.hidden]=\"mic_is_on === false\">\n            suivant\n          </span>\n        </a>\n      </div>\n      <div class=\"row\">\n        <div class=\"col-xs-12 text-center\" *ngIf=\"selectedSlide && howto\">\n          <h2>{{selectedSlide.index+1}}/{{howto.length}}</h2>\n        </div>\n      </div>\n      <div class=\"row hidden-md hidden-lg\">\n      <a class=\"col-xs-2 arrow-sm \" (click)=\"before()\">\n          <img src=\"/assets/before.svg\"/>\n      </a>\n      <a class=\"col-xs-2 arrow-sm\" (click)=\"after()\">\n          <img src=\"/assets/after.svg\"/>\n      </a>\n      </div>\n      <div class=\"row button text-center\">\n        <span>\n          <i [class.fa-microphone-slash]=\"mic_is_on === false\" \n          [class.fa-microphone]=\"mic_is_on === true\"\n          class=\"fa\" aria-hidden=\"true\"\n          (click)=\"toogleMic()\">\n          </i>\n        </span>\n      </div>\n    </div>\n  ",
            styles: ["\n   h1{\n    text-align:center;\n  }\n\n  .diapo_container {\n    height: 65vh;\n    width:100%;\n  }\n  @media screen and (max-width: 992px) {\n    .diapo_container{\n      height: 40vh;\n    } \n    .img_container{\n      line-height: 40vh;\n    }\n    a{\n      height:initial !important;\n    }\n\n  }\n  a{\n    height: 100%;\n    display: flex;\n    cursor: pointer;\n  }\n  a img{\n    height: 30%;\n    margin: auto; /* eh oui, tout b\u00EAtement */\n  }\n  a span{\n\n  }\n  .img_container{\n    border: solid black 3px;\n    border-radius: 3px;\n    width:100%;\n\n    height:100%;\n    line-height: 65vh;\n    text-align:center;\n  }\n\n  .img_container img{\n    max-width:100%;\n    max-height:100%;\n    display:inline;\n  }\n  arrow-sm img{\n    width:100%;\n  }\n  .button span i{\n    font-size: 35px;\n    cursor: pointer;\n  }\n\n  "]
        }), 
        __metadata('design:paramtypes', [slide_service_1.SlideService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map