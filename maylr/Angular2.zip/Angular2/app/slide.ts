export class Slide{
	index: number;
	img: string;
}
