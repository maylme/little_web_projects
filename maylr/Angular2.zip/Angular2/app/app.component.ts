import { Component} from '@angular/core';
import { Slide } from './slide';
import { SlideService } from './slide.service';
import { OnInit } from '@angular/core';

@Component({
  selector: 'my-app',
  providers: [SlideService],
  template: `
    <h1>How to :{{title}}</h1>
    <div class="container-fluid">
      <div class="diapo_container row">
        <a class="col-md-2 arrow hidden-sm hidden-xs" (click)="before()">
          <img src="/assets/before.svg"/>
          <span [class.hidden]="mic_is_on === false">
            precedant
          </span>
        </a>
        <div class="col-md-8" > 
            <div class="img_container" *ngIf="selectedSlide">
              <img [src]="selectedSlide.img" />
            </div>
        </div>
        <a class="col-md-2 arrow hidden-sm hidden-xs" (click)="after()">
          <img src="/assets/after.svg"/>
          <span [class.hidden]="mic_is_on === false">
            suivant
          </span>
        </a>
      </div>
      <div class="row">
        <div class="col-xs-12 text-center" *ngIf="selectedSlide && howto">
          <h2>{{selectedSlide.index+1}}/{{howto.length}}</h2>
        </div>
      </div>
      <div class="row hidden-md hidden-lg">
      <a class="col-xs-2 arrow-sm " (click)="before()">
          <img src="/assets/before.svg"/>
      </a>
      <a class="col-xs-2 arrow-sm" (click)="after()">
          <img src="/assets/after.svg"/>
      </a>
      </div>
      <div class="row button text-center">
        <span>
          <i [class.fa-microphone-slash]="mic_is_on === false" 
          [class.fa-microphone]="mic_is_on === true"
          class="fa" aria-hidden="true"
          (click)="toogleMic()">
          </i>
        </span>
      </div>
    </div>
  `,
  styles: [`
   h1{
    text-align:center;
  }

  .diapo_container {
    height: 65vh;
    width:100%;
  }
  @media screen and (max-width: 992px) {
    .diapo_container{
      height: 40vh;
    } 
    .img_container{
      line-height: 40vh;
    }
    a{
      height:initial !important;
    }

  }
  a{
    height: 100%;
    display: flex;
    cursor: pointer;
  }
  a img{
    height: 30%;
    margin: auto; /* eh oui, tout bêtement */
  }
  a span{

  }
  .img_container{
    border: solid black 3px;
    border-radius: 3px;
    width:100%;

    height:100%;
    line-height: 65vh;
    text-align:center;
  }

  .img_container img{
    max-width:100%;
    max-height:100%;
    display:inline;
  }
  arrow-sm img{
    width:100%;
  }
  .button span i{
    font-size: 35px;
    cursor: pointer;
  }

  `]
})
export class AppComponent implements OnInit{
  title = 'NickelRing';
  selectedSlide: Slide;
  howto: Slide[];
  mic_is_on = false;
  onSelect(slide: Slide): void {
    this.selectedSlide = slide;
  };
  after(): void{
    console.log("after", this.selectedSlide);
    if (this.selectedSlide == undefined){
      var next_index = 0;
    }else{
      var next_index = ((this.selectedSlide.index +1) >= this.howto.length)? 0: (this.selectedSlide.index +1);
    }
    this.selectedSlide = this.howto[next_index];
  };
  before(): void{
    if (this.selectedSlide == undefined){
      var next_index = this.howto.length - 1;
    }else{
      var next_index = ((this.selectedSlide.index - 1) < 0)? this.howto.length - 1: (this.selectedSlide.index -1);
    }
    this.selectedSlide = this.howto[next_index];

  };
  constructor(private slideService: SlideService) { };

  getSlides(): void {
    this.slideService.getSlides().then(slides => {
      this.howto = slides;
      this.selectedSlide = slides[0];

    });
  };

  ngOnInit(): void {
    this.getSlides();
  };
  toogleMic(): void{
    this.mic_is_on = !this.mic_is_on;

    if (annyang) {
      if(this.mic_is_on){
          var commands = {
              'back': ()=>{ 
                this.before();
              },
              'next': ()=>{
                this.after();
              },
              'help': ()=>{ alert("say 'next' or 'back' to navigate"); }
          };
          annyang.addCommands(commands);
          annyang.start();
      } else {
          annyang.removeCommands();
          annyang.abort();
      }
    }
  }
}