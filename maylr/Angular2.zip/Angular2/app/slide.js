"use strict";
var Slide = (function () {
    function Slide() {
    }
    return Slide;
}());
exports.Slide = Slide;
//# sourceMappingURL=slide.js.map